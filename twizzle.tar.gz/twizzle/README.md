# Twizzle

## Installation

1) Install [node.js](https://nodejs.org/en/)
2) Run the script located at `twizzle/sql/social.sql`
2) From the command line `cd path/to/twizzle; npm install`
3) `node index.js`
4) Go to [http://localhost:3000](http://localhost:3000)

To run the `social.sql` script you can try `mysql -uUSERNAME -p < /PATH/TO/social.sql` or from the mysql command line try `source ./PATH/TO/social.sql`.
