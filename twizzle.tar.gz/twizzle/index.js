const port = 3000;
const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const hb = require('express-handlebars');
const app = express();
app.use(express.static('static'));
app.use(session({ secret: 'csc336' }));
app.use(bodyParser.urlencoded({ extended: true }));

const mysql = require('mysql');
const pool = mysql.createPool({
  host     : 'localhost',
  user     : 'jac',
  password : 'password',
  database : 'twizzle',
  multipleStatements : true,
  // A `connectionLimit` of 4 works nicely on my machine.  YMMV.
  connectionLimit : 4
});

const query_users = 'SELECT name FROM users ORDER BY name;';
const query_followers = 'SELECT * FROM follows JOIN users ON follower = name WHERE followee = ? ORDER BY started';
const query_followees = 'SELECT * FROM follows JOIN users ON followee = name WHERE follower = ? ORDER BY started';
const query_twizzles = 'SELECT * FROM twizzles JOIN follows ON name = followee NATURAL JOIN users WHERE follower = ? OR name = ? ORDER BY posted';
const query_create_user = 'INSERT INTO users (name, displayname) VALUES (?, ?)';
const query_follow = 'INSERT INTO follows (follower, followee) VALUES (?, ?)';
const query_post_twizzle = 'INSERT INTO twizzles (name, content) VALUES (?, ?)';

app.engine('handlebars', hb({defaultLayout: 'main'}));
app.set('view engine', 'handlebars');
app.use(express.urlencoded());

function checkAuth(req, res, next) {
    if (!req.session.user_id) {
        res.redirect(302, '/login');
    } else {
        next();
    }
}

function db(req, res, next) {
    pool.getConnection((error, connection) => {
        try {
            if (error) {
                console.error('Error connecting to the database.', error);
                res.render('error', { error });
            } else {
                req.connection = connection;
                next();
            }
        } finally {
            connection.release();
        }
    });
}

app.get('/login', db, function (req, res) {
    req.connection.query(query_users, (error, results, fields) => {
        if (error) {
            res.render('error', { error });
        } else {
            res.render('login', { results });
        }
    });
});

app.post('/login', function (req, res) {
    req.session.user_id = req.body.user
    res.redirect('/');
});

app.post('/logout', function (req, res) {
    delete req.session.user_id;
    res.redirect('/login');
});

app.get('/', db, checkAuth, function(req, res) {
    req.connection.query(query_twizzles, [req.session.user_id, req.session.user_id], (error, stream, fields) => {
        req.connection.query(query_followees, [req.session.user_id], (error, followees, fields) => {
            req.connection.query(query_followers, [req.session.user_id], (error, followers, fields) => {
                if (error) {
                    res.render('error', { error });
                } else {
                    res.render('stream', { stream, followers, followees });
                }
            });
        });
    });
});

app.post('/post', db, checkAuth, function(req, res) {
    req.connection.query(query_post_twizzle, [req.session.user_id, req.body.twizzle], (error, stream, fields) => {
        if (error) {
            res.render('error', { error });
        } else {
            res.redirect(302, '/');
        }
    });
});


app.post('/api/user', db, function(req, res) {
    if (!req.body) {
        res.redirect(500, '/login?error=unknown');
    }

    req.connection.query(query_create_user, [req.body.user_name, req.body.display_name], (error, result, fields) => {
        if (error) {
            res.redirect(500, '/login?error=unknown');
            return;
        }
        res.redirect(302, '/');
    });
});

app.post('/follow', db, function(req, res) {
    console.log('Rx request to follow user.');
    console.log(req.session.user_id, req.body);
    if (!req.body) {
        console.error('Error following user: no body.');
        res.redirect(400, '/?error=unknown');
    }

    req.connection.query(query_follow, [req.session.user_id, req.body.follow], (error, result, fields) => {
        if (error) {
            console.error('Error following user:', error);
            res.redirect(500, '/?error=unknown');
            return;
        }
        res.redirect(302, '/');
    });
});

app.get('/error', db, function(req, res) {
    res.render('error', { error: req.query.type === 'preview' ? 'Cannot preview.' : 'Unknown error.' });
});

app.listen(3000);

