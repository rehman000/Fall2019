DROP DATABASE IF EXISTS twizzle;
CREATE DATABASE twizzle;
USE twizzle;

ROP TABLE IF EXISTS users;
CREATE TABLE users(
    name VARCHAR(16),
    displayname VARCHAR(32),
    joined DATETIME DEFAULT CURRENT_TIMESTAMP
);

DROP TABLE IF EXISTS twizzles;
CREATE TABLE twizzles(
    name VARCHAR(16),
    content VARCHAR(256),
    posted DATETIME DEFAULT CURRENT_TIMESTAMP
);

DROP TABLE IF EXISTS follows;
CREATE TABLE follows(
    follower VARCHAR(16),
    followee VARCHAR(16),
    started DATETIME DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO users VALUES ('jc', 'John Connor', '2016-01-01 01:01:01');
INSERT INTO users VALUES ('alice', 'Allice O''mally', '2017-02-02 02:02:02');
INSERT INTO users VALUES ('bob', 'Bob Dobbs', '2018-02-02 02:03:03');

INSERT INTO follows VALUES ('jc', 'alice', '2017-02-02 02:02:02');
INSERT INTO follows VALUES ('jc', 'bob', '2018-02-02 02:03:04');
INSERT INTO follows VALUES ('alice', 'bob', '2018-02-02 02:03:04');
INSERT INTO follows VALUES ('bob', 'jc', '2018-02-02 02:03:03');

INSERT INTO twizzles VALUES ('jc', 'Hello World!', '2016-01-01 01:01:02');
INSERT INTO twizzles VALUES ('alice', 'Hello Everybody!', '2017-02-02 02:02:03');

-- To view your stream
SELECT * FROM twizzles JOIN follows ON name = followee WHERE follower='jc';

